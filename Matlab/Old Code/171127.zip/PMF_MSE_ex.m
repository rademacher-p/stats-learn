% %%%%% PMF Learning
clear all;

%%% Inputs
M = 4;                      % PMF dimension
N = 8;                     % Number of training data

N_mc = 10000;                  % Number of monte carlo iterations



%%% Generate PMF set
fprintf('Generating PMF set... ');

L_set = 500;
Theta = N_bar_set(M,L_set)/L_set;

P_Theta = 1/size(Theta,2) * ones(1,size(Theta,2));      % Prior distribution

fprintf('Complete.');


%%% Iterate
loss = zeros(1,N_mc);
theta_mc = zeros(M,N_mc);

for idx_mc = 1:N_mc
     
    %%% Randomly select a generative PMF
    theta_mc(:,idx_mc) = Theta(:,randi(size(Theta,2)));
%     temp = find(rand <= cumsum(P_Theta));
%     theta_mc(:,idx_mc) = Theta(:,temp(1));


    %%% Generate training data
    D = zeros(1,N);
    for n = 1:N
        temp = find(rand <= cumsum(theta_mc(:,idx_mc)));
        D(:,n) = temp(1);
    end
    
    %%% Generate test datum
    temp = find(rand <= cumsum(theta_mc(:,idx_mc)));
    y = temp(1);    


    %%% Optimal Estimator
    N_bar = zeros(M,1);
    for m = 1:M
        N_bar(m) = sum(D == m);     % Sufficient Statistic
    end

    P_post = (M/(N+M))*(1/M*ones(M,1)) + (N/(N+M))*N_bar/N;   % E[theta | data] 
    
    y_est = (1:M)*P_post;       % Optimal
%     y_est = (M+1)/2;            % Prior-only
%     y_est = (1:M)*N_bar/N;      % Data-only
    

    %%% Assess loss    
    loss(idx_mc) = (y_est - y)^2;

end

Risk = mean(loss)

risk_prior = (M+1)*(M-1)/12;
risk_data = M*(M-1)*(N-1) / (12*N);
risk_cross = (M+1)*(2*M+1)/6 - M*(M-1)*(N-1)/(12*N) - (M+1)^2/4;
risk_opt_a = M/(N+M)*risk_prior + N/(N+M)*risk_data + N*M/(N+M)^2*risk_cross

risk_prior_emp = M/(N+M)*risk_prior + N/(N+M)*(risk_data + risk_cross)
risk_data_emp = M/(N+M)*(risk_prior + risk_cross) + N/(N+M)*risk_data




