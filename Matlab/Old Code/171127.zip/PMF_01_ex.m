%%%%% PMF Learning
clear all;

%%% Inputs
M = 2;                      % PMF dimension
N = 200;                     % Number of training data

M_loss = ones(M) - eye(M);  % Loss function  

N_mc = 10000;                  % Number of monte carlo iterations

%%% Generate PMF set
fprintf('Generating PMF set... ');

L_set = 100;
Theta = N_bar_set(M,L_set)/L_set;

P_Theta = 1/size(Theta,2) * ones(1,size(Theta,2));      % Prior distribution

fprintf('Complete.');


%%% Iterate
loss = zeros(1,N_mc);
theta_mc = zeros(M,N_mc);

for idx_mc = 1:N_mc
 
    %%% Randomly select a generative PMF
    theta_mc(:,idx_mc) = Theta(:,randi(size(Theta,2)));
%     temp = find(rand <= cumsum(P_Theta));
%     theta_mc(:,idx_mc) = Theta(:,temp(1));


    %%% Generate training data
    D = zeros(1,N);
    for n = 1:N
        temp = find(rand <= cumsum(theta_mc(:,idx_mc)));
        D(:,n) = temp(1);
    end
    
    %%% Generate test datum
    temp = find(rand <= cumsum(theta_mc(:,idx_mc)));
    y = temp(1);    


    %%% Optimal Estimator
    N_bar = zeros(M,1);
    for m = 1:M
        N_bar(m) = sum(D == m);     % Sufficient Statistic
    end

    P_post = (M/(N+M))*(1/M*ones(M,1)) + (N/(N+M))*N_bar/N;   % E[theta | data]

    [~,y_est] = min(M_loss*P_post);
    

    %%% Assess loss
    loss(idx_mc) = M_loss(y_est,y);
    

end

Risk = mean(loss)
Risk_anayltic = 1 - harmonic(M)/M



% % figure(1); clf;
% % plot3(theta_mc(1,:),theta_mc(2,:),loss,'b*');
% % grid on;

% %     %%% Plots
% %     figure(11); clf;
% %     stem(1:M,[theta,N_bar/N,P_y_post])
% %     grid on; axis([0.9,M+0.1,0,1]); 
% %     legend({'$\theta$','$\hat{\theta}_{ML}$','$E[\theta|D]$'},'Interpreter','latex');

