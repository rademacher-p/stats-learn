%%%

clear;
clc;

M = 4;
N = 10+randi([21,24]);


N_bar = N_bar_set(M,N);


%%%

N_max = max(N_bar);

C_max = zeros(1,N+1);
for n = (0:N)
    C_max(n+1) = numel(find(N_max == n));
end


C_g = zeros(1,N+1);
if M == 2
    for n = 0:N
%         if n > N/2
% %             C_g(n+1) = 2;
%             C_g(n+1) = M*nchoosek(N-n+M-2,M-2);
%         elseif n == N/2
%             C_g(n+1) = 1;
%         end
        
        if n >= (N+2)/2
%             C_g(n+1) = M*nchoosek(N-n+M-2,M-2);
            C_g(n+1) = nchoosek(2*n-N+1,1) - nchoosek(2*n-N-1,1);
        elseif n >= N/2
            C_g(n+1) = nchoosek(2*n-N+1,1);
        end
    end
elseif M == 3
    for n = 0:N
%         if n > N/2
% %             C_g(n+1) = 3*(N-n+1);
%             C_g(n+1) = M*nchoosek(N-n+M-2,M-2);
%         elseif (n > N/3) && (n <= N/2)
%             C_g(n+1) = 3*(3*n-N);
%         elseif n == N/3
%             C_g(n+1) = 1;
%         end
        
%         if (n > floor(N/2))%n > N/2
%             C_g(n+1) = M*nchoosek(N-n+M-2,M-2);
%         elseif (n > ceil(N/3)) && (n <= floor(N/2)) %(n >= N/3+1) && (n <= N/2)
%             C_g(n+1) = nchoosek(3*n-N+2,2) - nchoosek(3*n-N-1,2);
%         elseif n == ceil(N/3) %(n >= N/3) && (n < N/3+1)
%             C_g(n+1) = nchoosek(3*n-N+2,2);
%         end
        
        if n >= (N+3)/2
            C_g(n+1) = nchoosek(3*n-N+2,2) - nchoosek(3*n-N-1,2) ...
                - 3*(nchoosek(2*n-N+1,2) - nchoosek(2*n-N-1,2));
        elseif n >= (N+1)/2
            C_g(n+1) = nchoosek(3*n-N+2,2) - nchoosek(3*n-N-1,2) ...
                - 3*nchoosek(2*n-N+1,2);
        elseif n >= (N+3)/3
            C_g(n+1) = nchoosek(3*n-N+2,2) - nchoosek(3*n-N-1,2);
        elseif n >= N/3
            C_g(n+1) = nchoosek(3*n-N+2,2);
        end
        
    end
elseif M == 4
    for n = 0:N
        if n >= (N+4)/2 %> N/2
%             C_g(n+1) = M*nchoosek(N-n+M-2,M-2);
            C_g(n+1) = nchoosek(4*n-N+3,3) - nchoosek(4*n-N-1,3) ...
                - 4*(nchoosek(3*n-N+2,3) - nchoosek(3*n-N-1,3) ...
                - 3/2*(nchoosek(2*n-N+1,3) - nchoosek(2*n-N-1,3)));
            
            
        elseif n >= (N+2)/2
            C_g(n+1) = nchoosek(4*n-N+3,3) - nchoosek(4*n-N-1,3) ...
                - 4*(nchoosek(3*n-N+2,3) - nchoosek(3*n-N-1,3) ...
                - 3/2*nchoosek(2*n-N+1,3));
            
%         elseif n >= N/2
%             C_g(n+1) = nchoosek(4*n-N+3,3) - nchoosek(4*n-N-1,3) ...
%                 - 4*(nchoosek(3*n-N+2,3) - nchoosek(3*n-N-1,3) ...
%                 - 3/2*(nchoosek(2*n-N+3,3)));
%             
%             n
%             nchoosek(2*n-N+3,3)
%             C_max(n+1) - (nchoosek(4*n-N+3,3) - nchoosek(4*n-N-1,3) - 4*(nchoosek(3*n-N+2,3) - nchoosek(3*n-N-1,3)))

        elseif n >= (N+4)/3
            C_g(n+1) = nchoosek(4*n-N+3,3) - nchoosek(4*n-N-1,3) ...
                - 4*(nchoosek(3*n-N+2,3) - nchoosek(3*n-N-1,3));
            
        elseif n >= (N+1)/3
            C_g(n+1) = nchoosek(4*n-N+3,3) - nchoosek(4*n-N-1,3) ...
                - 4*nchoosek(3*n-N+2,3);
            
        elseif n >= (N+4)/4
            C_g(n+1) = nchoosek(4*n-N+3,3) - nchoosek(4*n-N-1,3);
        elseif n >= N/4
            C_g(n+1) = nchoosek(4*n-N+3,3);
        end
    end
end




%%% Plots
figure(1); clf;
plot(0:N,C_max,'bo',0:N,C_g,'r*');
grid on; xlabel('N_{max}'); ylabel('#'); title(['M = ',num2str(M),' , N = ',num2str(N)]);
hold on; plot(N/2*[1,1],[0,max(C_max)],'g',N/3*[1,1],[0,max(C_max)],'g',N/4*[1,1],[0,max(C_max)],'g');

% figure(5); clf; plot(0:N,cumsum(C_max),'bo'); grid on;

if M == 2
%     figure(2); clf;
%     plot(N_bar(1,:),N_bar(2,:),'bo');
%     grid on; xlabel('N_1'); ylabel('N_2');
    
%     figure(3); clf;
%     scatter(N_bar(1,:),N_bar(2,:),[],N_max,'filled');
% %     scatter3(N_bar(1,:),N_bar(2,:),N_max,[],N_max,'filled');
%     grid on; xlabel('N_1'); ylabel('N_{max}');
elseif M == 3
%     figure(2); clf;
%     plot3(N_bar(1,:),N_bar(2,:),N_bar(3,:),'bo');
%     grid on; xlabel('N_1'); ylabel('N_2'); zlabel('N_3');
    
%     figure(3); clf;
%     scatter3(N_bar(1,:),N_bar(2,:),N_bar(3,:),[],N_max,'filled');
% %     scatter3(N_bar(1,:),N_bar(2,:),N_max,[],N_max,'filled');
%     grid on; xlabel('N_1'); ylabel('N_2'); zlabel('N_{max}');
    
    
%     for n = N
%         idx = find(N_max == n);
%         figure(4); clf;
% %         plot(N_bar(1,idx),N_bar(2,idx),'bo');
%         plot3(N_bar(1,idx),N_bar(2,idx),N_bar(3,idx),'bo');
%         grid on; xlabel('N_1'); ylabel('N_2'); title(num2str(n));
%         view([-30,30]); axis([0,N,0,N]); pause(1);
%     end
elseif M == 4
%     figure(2); clf;
%     plot3(N_bar(1,:),N_bar(2,:),N_bar(3,:),'bo');
%     grid on; xlabel('N_1'); ylabel('N_2'); zlabel('N_3');
%     
%     figure(3); clf;
%     scatter3(N_bar(1,:),N_bar(2,:),N_bar(3,:),[],N_max,'filled');
%     grid on; xlabel('N_1'); ylabel('N_2'); zlabel('N_3');
    
%     for n = ceil(N/2):ceil(N/1)
%         idx = find(N_max == n);
%         figure(4); clf;
%         plot3(N_bar(1,idx),N_bar(2,idx),N_bar(3,idx),'bo');
%         grid on; xlabel('N_1'); ylabel('N_2'); zlabel('N_3'); title(num2str(n));
%         axis([0,N,0,N,0,N]); view([0,90]); pause(2);
%     end
end





