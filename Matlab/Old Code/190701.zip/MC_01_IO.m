%%%%% PMF Learning
clear all;

%%% Inputs
M_y = 4;                    % Output dimension
M_x = 3;                    % Input dimension

N = 10;                      % Number of training data

M_loss = ones(M_y) - eye(M_y);  % Loss function  

N_mc = 1000000;                  % Number of monte carlo iterations


%%% Iterate
M = M_y*M_x;

loss = zeros(1,N_mc);
for idx_mc = 1:N_mc
    
    if mod(idx_mc,1000) == 0
        disp(['Iteration ',num2str(idx_mc),'/',num2str(N_mc)]);
    end
 
    %%% Randomly select a generative PMF    
    % http://blog.geomblog.org/2005/10/sampling-from-simplex.html
    temp = -log(rand(M_y,M_x));
    theta = temp / sum(temp(:));
    

    %%% Generate training data
    D = struct('y',cell(N,1),'x',cell(N,1));
    for n = 1:N
        temp = find(rand <= cumsum(theta(:)));
        [D(n).y,D(n).x] = ind2sub([M_y,M_x],temp(1)); 
    end
    
    %%% Generate test datum
    temp = find(rand <= cumsum(theta(:)));
    [y,x] = ind2sub([M_y,M_x],temp(1));


    %%% Optimal Estimator
    N_bar = zeros(M_y,M_x);
    for n = 1:N
        N_bar(D(n).y,D(n).x) = N_bar(D(n).y,D(n).x) + 1;
    end


    P_y_xD = (N_bar(:,x) + 1) / (sum(N_bar(:,x)) + M_y);

    [~,h] = min(M_loss*P_y_xD);
    

    %%% Assess loss
    loss(idx_mc) = M_loss(h,y);
    
end

Risk = mean(loss);

Risk_an = 1;
for m = 1:M_y
    for n = 0:ceil((N+M)/m)-1
        Risk_an = Risk_an + M_x/(N+M) * (-1)^m * nchoosek(M_y,m) * prod(1 - m*n./(N+(1:M-1)));
    end
end

Risk_an_inf = 1 - harmonic(M_y)/M_y;
Risk_an_zero = 1 - 1/M_y;



Risk
Risk_an
Risk_an_inf
Risk_an_zero



