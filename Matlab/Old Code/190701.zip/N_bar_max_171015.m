%%%

clear;
clc;

M = 2;
N = 100;


N_bar = N_bar_set(M,N);


%%%

N_max = max(N_bar);
C_max = zeros(1,N+1);
for n = (0:N)
    C_max(n+1) = numel(find(N_max == n));
end


C_g = zeros(1,N+1);
for m = M:-1:1
    for n = 0:N
        if n >= (N+M-m)/m
            C_g(n+1) = C_g(n+1) + (-1)^(M-m) * nchoosek(M,m) * nchoosek(m*n-N+m-1,M-1);
        end
    end
end
temp = C_g;
C_g = C_g - [0, C_g(1:end-1)]; %%% CDF!?!?!?!?


CMF = temp / nchoosek(N+M-1,M-1);
PMF = CMF - [0, CMF(1:end-1)];


%%%

mu_emp = mean(N_max);
mu = sum((0:N).*PMF);

% mu*(1:20)

% (3*N+1)/4
% Risk = 1 - (mu+1)/(N+M)


%%%%%
C_lim = zeros(1,N+1);
mu_lim = 0;
mu_lim_2 = 0;
t = (0:N)/N;
for m = M:-1:1
    mu_lim = mu_lim + (-1)^(M-m) * nchoosek(M,m) * (m-1)^(M-1) * (1-(m-1)/(m*M));
    mu_lim_2 = mu_lim_2 - (1/M) * (-1)^m * nchoosek(M,m) * (1/m);
    for idx = 1:N+1
        if t(idx) >= 1/m
            C_lim(idx) = C_lim(idx) + (-1)^(M-m) * nchoosek(M,m) * (m*t(idx)-1)^(M-1);
        end
    end
end

P_lim = (C_lim - [0, C_lim(1:end-1)]) / N;   % differentiation

mu_lim
mu_lim_2
mu_lim_approx = N*sum(t.*P_lim);         % note integration approx error...



%%% Plots
figure(1); clf;
plot(0:N,C_max,'bo',0:N,C_g,'r*');
grid on; xlabel('N_{max}'); ylabel('#'); title(['\Delta = ',num2str(sum(abs(C_max-C_g)))]);
% hold on; plot(N/2*[1,1],[0,max(C_max)],'g',N/3*[1,1],[0,max(C_max)],'g',N/4*[1,1],[0,max(C_max)],'g');

figure(2); clf; 
subplot(2,1,1); plot(0:N,CMF,'bo'); 
grid on; xlabel('N_{max}'); ylabel('CMF'); title(['M = ',num2str(M),' , N = ',num2str(N)]);
subplot(2,1,2); plot(0:N,PMF,'bo'); 
grid on; xlabel('N_{max}'); ylabel('PMF'); title(['\mu = ',num2str(mu)]);


figure(6); clf; 
subplot(2,1,1); plot(t,CMF,'bo',t,C_lim,'r.'); grid on; title(['\Delta = ',num2str(sum(abs(CMF-C_lim))/N)]);
subplot(2,1,2); plot(t,PMF,'bo',t,N*P_lim,'r.'); grid on; title(['\mu_{lim} = ',num2str(mu_lim)]);
% subplot(2,1,2); plot(t,C_lim - CMF,'bo'); grid on;


if M == 2
%     figure(2); clf;
%     plot(N_bar(1,:),N_bar(2,:),'bo');
%     grid on; xlabel('N_1'); ylabel('N_2');
    
%     figure(3); clf;
%     scatter(N_bar(1,:),N_bar(2,:),[],N_max,'filled');
% %     scatter3(N_bar(1,:),N_bar(2,:),N_max,[],N_max,'filled');
%     grid on; xlabel('N_1'); ylabel('N_{max}');
elseif M == 3
%     figure(2); clf;
%     plot3(N_bar(1,:),N_bar(2,:),N_bar(3,:),'bo');
%     grid on; xlabel('N_1'); ylabel('N_2'); zlabel('N_3');
    
%     figure(3); clf;
%     scatter3(N_bar(1,:),N_bar(2,:),N_bar(3,:),[],N_max,'filled');
% %     scatter3(N_bar(1,:),N_bar(2,:),N_max,[],N_max,'filled');
%     grid on; xlabel('N_1'); ylabel('N_2'); zlabel('N_{max}');
    
    
%     for n = N
%         idx = find(N_max == n);
%         figure(4); clf;
% %         plot(N_bar(1,idx),N_bar(2,idx),'bo');
%         plot3(N_bar(1,idx),N_bar(2,idx),N_bar(3,idx),'bo');
%         grid on; xlabel('N_1'); ylabel('N_2'); title(num2str(n));
%         view([-30,30]); axis([0,N,0,N]); pause(1);
%     end
elseif M == 4
%     figure(2); clf;
%     plot3(N_bar(1,:),N_bar(2,:),N_bar(3,:),'bo');
%     grid on; xlabel('N_1'); ylabel('N_2'); zlabel('N_3');
%     
%     figure(3); clf;
%     scatter3(N_bar(1,:),N_bar(2,:),N_bar(3,:),[],N_max,'filled');
%     grid on; xlabel('N_1'); ylabel('N_2'); zlabel('N_3');
    
%     for n = ceil(N/2):ceil(N/1)
%         idx = find(N_max == n);
%         figure(4); clf;
%         plot3(N_bar(1,idx),N_bar(2,idx),N_bar(3,idx),'bo');
%         grid on; xlabel('N_1'); ylabel('N_2'); zlabel('N_3'); title(num2str(n));
%         axis([0,N,0,N,0,N]); view([0,90]); pause(2);
%     end
end





