%%%%%%%%%%

clear;
clc;

M = 5;
N = 60;


N_bar = N_bar_set(M,N);
L_set = size(N_bar,2);


%%%
N_max_set = zeros(M,L_set);
for m = 1:M
    N_max_set(m,:) = max(N_bar(1:m,:),[],1);
end

CMF_emp = zeros(M,N+1);
for m = 1:M
    for n = (0:N)
        CMF_emp(m,n+1) = numel(find(N_max_set(m,:) <= n)) / L_set;
    end
end
PMF_emp = CMF_emp - [zeros(M,1), CMF_emp(:,1:end-1)];

mu_emp = mean(N_max_set,2);



%%% incomplete
CMF = zeros(M,N+1);
for m = M:-1:1
    for n = 0:N
        if n >= (N+M-m)/m
            CMF(M,n+1) = CMF(M,n+1) + (-1)^(M-m) * nchoosek(M,m) * nchoosek(m*n-N+m-1,M-1) / L_set;
        end
    end
end
PMF = CMF - [zeros(M,1), CMF(:,1:end-1)];




%%%%%
N_lim = 50000;

t = (0:N_lim)/N_lim;

CMF_lim = zeros(M,N_lim+1);
for k = 1:M
    for m = 0:k
        idx = find((t >= 0) & (t < 1/m));
        CMF_lim(k,idx) = CMF_lim(k,idx) + (-1)^m * nchoosek(k,m) * (1-m*t(idx)).^(M-1);
    end
end
PMF_lim = (CMF_lim - [zeros(M,1), CMF_lim(:,1:end-1)]) * N_lim;   % differentiation

mu_lim_ap = sum(t.*PMF_lim,2)/N_lim;        % note integration approx error...



%%%
mu_lim_an = 1/M*cumsum(1./(1:M))';


mu_emp/N
% mu/N


mu_lim_ap
mu_lim_an



% %%% Plots
% figure(1); clf; 
% subplot(2,1,1); plot(0:N,CMF(M,:),'bo',0:N,CMF_emp(end,:),'r.'); 
% grid on; xlabel('N_{max}'); ylabel('CMF'); title(['M = ',num2str(M),' , N = ',num2str(N)]);
% subplot(2,1,2); plot(0:N,PMF(M,:),'bo',0:N,PMF_emp(end,:),'r.'); 
% % hold on; plot(N/2*[1,1],[0,max(C_max)],'g',N/3*[1,1],[0,max(C_max)],'g',N/4*[1,1],[0,max(C_max)],'g');
% grid on; xlabel('N_{max}'); ylabel('PMF'); %title(['\mu = ',num2str(mu)]); %title(['\Delta = ',num2str(sum(abs(PMF-PMF_emp)))]);
% 
% 
% figure(2); clf; 
% subplot(2,1,1); plot((0:N)/N,CMF(M,:),'bo',t,CMF_lim(M,:),'r'); grid on; title('Infinite N');
% subplot(2,1,2); plot((0:N)/N,PMF(M,:)*N,'bo',t,PMF_lim(M,:),'r'); grid on; title(['\mu_{lim}/N = ',num2str(mu_lim_ap)]);
% % subplot(2,1,2); plot(t,C_lim - CMF,'bo'); grid on;


figure(4); clf;
plot((0:N)/N,CMF_emp,'bo',t,CMF_lim,'r');
grid on; %axis([0,1,0,1]);







