%%%%% PMF Learning
clear all;

%%% Inputs
M = 6;                      % PMF dimension
N = 5;                     % Number of training data

M_loss = ones(M) - eye(M);  % Loss function  

N_mc = 50000;                  % Number of monte carlo iterations


% %%% Generate PMF set
% fprintf('Generating PMF set... ');
% 
% L_set = 100;
% Theta = N_bar_set(M,L_set)/L_set;
% 
% P_Theta = 1/size(Theta,2) * ones(1,size(Theta,2));      % Prior distribution
% 
% fprintf('Complete.');


%%% Iterate
loss = zeros(1,N_mc);
for idx_mc = 1:N_mc
 
    %%% Randomly select a generative PMF
    
    % http://blog.geomblog.org/2005/10/sampling-from-simplex.html
    temp = -log(rand(M,1));
    theta_mc = temp / sum(temp);
    
%     theta_mc(:,idx_mc) = Theta(:,randi(size(Theta,2)));
% %     temp = find(rand <= cumsum(P_Theta));
% %     theta_mc(:,idx_mc) = Theta(:,temp(1));


    %%% Generate training data
    D = zeros(1,N);
    for n = 1:N
        temp = find(rand <= cumsum(theta_mc));
        D(:,n) = temp(1);
    end
    
    %%% Generate test datum
    temp = find(rand <= cumsum(theta_mc));
    y = temp(1);    


    %%% Optimal Estimator
    N_bar = zeros(M,1);
    for m = 1:M
        N_bar(m) = sum(D == m);    
    end

    P_y_D = (N_bar + 1) / (N+M);

    [~,h] = min(M_loss*P_y_D);
    

    %%% Assess loss
    loss(idx_mc) = M_loss(h,y);
    
end

Risk = mean(loss);

Risk_an = -1/(N+M);
for m = 1:M
    for n = ceil((N+M)/m):(N+M)
        Risk_an = Risk_an + -1/(N+M) * (-1)^m * nchoosek(M,m) * prod(1 - m*n./(N+(1:M-1)));
    end
end   

Risk_an_lim = 1 - harmonic(M)/M;
Risk_an_naive = 1 - 1/M;



Risk
Risk_an
Risk_an_lim
Risk_an_naive




% %     %%% Plots
% %     figure(11); clf;
% %     stem(1:M,[theta,N_bar/N,P_y_post])
% %     grid on; axis([0.9,M+0.1,0,1]); 
% %     legend({'$\theta$','$\hat{\theta}_{ML}$','$E[\theta|D]$'},'Interpreter','latex');

