%%%%%%%%%%

clear;
clc;

M = 4;
N = 100;


N_bar = N_bar_set(M,N);


%%%

N_max = max(N_bar);
L_set = size(N_bar,2);

PMF_emp = zeros(1,N+1);
for n = (0:N)
    PMF_emp(n+1) = numel(find(N_max == n)) / L_set;
end


CMF = zeros(1,N+1);
for m = M:-1:1
    for n = 0:N
        if n >= (N+M-m)/m
            CMF(n+1) = CMF(n+1) + (-1)^(M-m) * nchoosek(M,m) * nchoosek(m*n-N+m-1,M-1) / L_set;
        end
    end
end
PMF = CMF - [0, CMF(1:end-1)];



%%%

mu_emp = mean(N_max);
mu = sum((0:N).*PMF);


% moo = N;
% for m = 1:M
%     temp = 0;
%     for n = ceil((N+M)/m):N
%         temp = temp + nchoosek(m*n-N-1,M-1);
%     end
%     moo = moo - (-1)^(M-m) * nchoosek(M,m) * temp / L_set;
% end



%%%%%
N_lim = 50000;

C_lim = zeros(1,N_lim+1);
% mu_lim = 0;
% mu_lim_2 = 0;
t = (0:N_lim)/N_lim;
for m = M:-1:1
%     mu_lim = mu_lim + (-1)^(M-m) * nchoosek(M,m) * (m-1)^(M-1) * (1-(m-1)/(m*M));
%     mu_lim_2 = mu_lim_2 - (1/M) * (-1)^m * nchoosek(M,m) * (1/m);
    for idx = 1:N_lim+1
        if t(idx) >= 1/m
            C_lim(idx) = C_lim(idx) + (-1)^(M-m) * nchoosek(M,m) * (m*t(idx)-1)^(M-1);
        end
    end
end
P_lim = (C_lim - [0, C_lim(1:end-1)]) * N_lim;   % differentiation



% % mu_3 = 0;
% % mu_4 = 0;
% % for k = 0:(M-1)
% %     mu_3 = mu_3 + (-1)^k * nchoosek(M-1,k) * (k+1)^-2;
% %     mu_4 = mu_4 + (1/M) * (1/(k+1));
% % end
% % mu_3
% % mu_4

% mu_5 = harmonic(M)/M;
mu_lim_an = 1/M*sum(1./(1:M));


mu_emp/N
mu/N

mu_lim_an
mu_lim_approx = sum(t.*P_lim)/N_lim        % note integration approx error...


% Risk = 1 - (mu+1)/(N+M)



%%% Plots
figure(1); clf; 
subplot(2,1,1); plot(0:N,CMF,'bo'); 
grid on; xlabel('N_{max}'); ylabel('CMF'); title(['M = ',num2str(M),' , N = ',num2str(N)]);
subplot(2,1,2); plot(0:N,PMF,'bo',0:N,PMF_emp,'r.'); 
% hold on; plot(N/2*[1,1],[0,max(C_max)],'g',N/3*[1,1],[0,max(C_max)],'g',N/4*[1,1],[0,max(C_max)],'g');
grid on; xlabel('N_{max}'); ylabel('PMF'); title(['\mu = ',num2str(mu)]); %title(['\Delta = ',num2str(sum(abs(PMF-PMF_emp)))]);


figure(2); clf; 
subplot(2,1,1); plot((0:N)/N,CMF,'bo',t,C_lim,'r'); grid on; %title(['\Delta = ',num2str(sum(abs(CMF-C_lim))/N)]);
subplot(2,1,2); plot((0:N)/N,PMF*N,'bo',t,P_lim,'r'); grid on; title(['\mu_{lim} = ',num2str(mu_lim_approx)]);
% subplot(2,1,2); plot(t,C_lim - CMF,'bo'); grid on;


% % if M == 2
% % %     figure(2); clf;
% % %     plot(N_bar(1,:),N_bar(2,:),'bo');
% % %     grid on; xlabel('N_1'); ylabel('N_2');
% %     
% % %     figure(3); clf;
% % %     scatter(N_bar(1,:),N_bar(2,:),[],N_max,'filled');
% % % %     scatter3(N_bar(1,:),N_bar(2,:),N_max,[],N_max,'filled');
% % %     grid on; xlabel('N_1'); ylabel('N_{max}');
% % elseif M == 3
% % %     figure(2); clf;
% % %     plot3(N_bar(1,:),N_bar(2,:),N_bar(3,:),'bo');
% % %     grid on; xlabel('N_1'); ylabel('N_2'); zlabel('N_3');
% %     
% % %     figure(3); clf;
% % %     scatter3(N_bar(1,:),N_bar(2,:),N_bar(3,:),[],N_max,'filled');
% % % %     scatter3(N_bar(1,:),N_bar(2,:),N_max,[],N_max,'filled');
% % %     grid on; xlabel('N_1'); ylabel('N_2'); zlabel('N_{max}');
% %     
% %     
% % %     for n = N
% % %         idx = find(N_max == n);
% % %         figure(4); clf;
% % % %         plot(N_bar(1,idx),N_bar(2,idx),'bo');
% % %         plot3(N_bar(1,idx),N_bar(2,idx),N_bar(3,idx),'bo');
% % %         grid on; xlabel('N_1'); ylabel('N_2'); title(num2str(n));
% % %         view([-30,30]); axis([0,N,0,N]); pause(1);
% % %     end
% % elseif M == 4
% % %     figure(2); clf;
% % %     plot3(N_bar(1,:),N_bar(2,:),N_bar(3,:),'bo');
% % %     grid on; xlabel('N_1'); ylabel('N_2'); zlabel('N_3');
% % %     
% % %     figure(3); clf;
% % %     scatter3(N_bar(1,:),N_bar(2,:),N_bar(3,:),[],N_max,'filled');
% % %     grid on; xlabel('N_1'); ylabel('N_2'); zlabel('N_3');
% %     
% % %     for n = ceil(N/2):ceil(N/1)
% % %         idx = find(N_max == n);
% % %         figure(4); clf;
% % %         plot3(N_bar(1,idx),N_bar(2,idx),N_bar(3,idx),'bo');
% % %         grid on; xlabel('N_1'); ylabel('N_2'); zlabel('N_3'); title(num2str(n));
% % %         axis([0,N,0,N,0,N]); view([0,90]); pause(2);
% % %     end
% % end





