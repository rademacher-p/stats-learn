%%%
clear all;


L = 100;
M = 2;

theta = (0:L-1)'/L;

N = [10,30,50];

P = zeros(L,length(N));
for idx = 1:length(N)
    
    N_bar = floor(0.5*N(idx)); 
    
%     P(:,idx) = factorial(N(idx)+M-1)/(factorial(M-1)*factorial(N_bar)*factorial(N(idx)-N_bar))*...
%         theta.^N_bar .* (1-theta).^(N(idx)-N_bar);
    
    P(:,idx) = (N(idx)+1)*(1-theta).^N(idx);

    
end

figure(1); clf;
plot(theta,P);
grid on; xlabel('\theta'); ylabel('p(\theta | D)');
legend;