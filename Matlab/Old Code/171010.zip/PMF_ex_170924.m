%%%%% PMF Learning
clear all;

%%% Inputs
M = 3;
M_loss = ones(M) - eye(M);


%%% Import PMF set
L = 100;
Theta = PMF_set(M,L);


%%% Randomly select a generative PMF
P_T = 1/size(Theta,2) * ones(1,size(Theta,2));

temp = find(rand <= cumsum(P_T));
theta = Theta(:,temp(1));


%%% Generate training data
N = 10;
D = zeros(1,N);

for idx = 1:N
    temp = find(rand <= cumsum(theta));
    D(:,idx) = temp(1);
end


%%% Optimum Learner
N_bar = zeros(M,1);
for idx = 1:M
    N_bar(idx) = sum(D == idx);     % Sufficient Statistic

end

P_y_post = (M/(N+M))*(1/M*ones(M,1)) + (N/(N+M))*N_bar/N;   % E[theta | data]


[~,y_est] = min(M_loss*P_y_post);


%%% Generate test data
temp = find(rand <= cumsum(theta));
y = temp(1);


%%% Plots
figure(1); clf;
stem(1:M,[theta,N_bar/N,P_y_post])
grid on; axis([0.9,M+0.1,0,1]); 
legend({'$\theta$','$\hat{\theta}_{ML}$','$E[\theta|D]$'},'Interpreter','latex');


y_est
y





