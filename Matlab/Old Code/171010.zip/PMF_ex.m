%%%%% PMF Learning
clear all;

%%% Inputs
M = 3;                      % PMF dimension
N = 10;                     % Number of training data

M_loss = ones(M) - eye(M);  % Loss function  

N_mc = 10000;                  % Number of monte carlo iterations


%%% Import PMF set
L_set = 10;
Theta = PMF_set(M,L_set);

P_Theta = 1/size(Theta,2) * ones(1,size(Theta,2));      % Prior distribution


%%% Iterate
loss = zeros(1,N_mc);
theta_mc = zeros(M,N_mc);

for idx_mc = 1:N_mc
 
    %%% Randomly select a generative PMF
    temp = find(rand <= cumsum(P_Theta));
    theta_mc(:,idx_mc) = Theta(:,temp(1));


    %%% Generate training data
    D = zeros(1,N);
    for n = 1:N
        temp = find(rand <= cumsum(theta_mc(:,idx_mc)));
        D(:,n) = temp(1);
    end
    
    %%% Generate test datum
    temp = find(rand <= cumsum(theta_mc(:,idx_mc)));
    y = temp(1);    
%     N_test = 100;
%     Y = zeros(1,N_test);
%     for idx = 1:N_test
%         temp = find(rand <= cumsum(theta_mc(:,idx_mc)));
%         Y(:,idx) = temp(1);
%     end %%%%%%%%%%%%%%%%%%%%%%%%


    %%% Optimal Estimator
    N_bar = zeros(M,1);
    for m = 1:M
        N_bar(m) = sum(D == m);     % Sufficient Statistic
    end

    P_y_post = (M/(N+M))*(1/M*ones(M,1)) + (N/(N+M))*N_bar/N;   % E[theta | data]

    [~,y_est] = min(M_loss*P_y_post);
    

    %%% Assess loss
    loss(idx_mc) = M_loss(y_est,y);
    
%     loss_temp = zeros(1,N_test);
%     for idx = 1:N_test
%         loss_temp(idx) = M_loss(y_est,Y(idx));
%     end
%     loss(idx_mc) = mean(loss_temp); %%%%%%%%%%%%%%%%%%%%%%%%%%


%     %%% Plots
%     figure(11); clf;
%     stem(1:M,[theta,N_bar/N,P_y_post])
%     grid on; axis([0.9,M+0.1,0,1]); 
%     legend({'$\theta$','$\hat{\theta}_{ML}$','$E[\theta|D]$'},'Interpreter','latex');

end

Risk = mean(loss)

figure(1); clf;
plot3(theta_mc(1,:),theta_mc(2,:),loss,'b*');
grid on;

