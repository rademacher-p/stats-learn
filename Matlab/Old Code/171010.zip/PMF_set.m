function Theta = PMF_set(M,L)

P = (0:L);

for m = 2:M-1
    P_0 = P;
    P = [];
    for idx = 1:size(P_0,2)
        P = [P, [P_0(:,idx)*ones(1,L-sum(P_0(:,idx))+1) ; 0:(L-sum(P_0(:,idx)))] ];
    end
end

P = [P ; L-sum(P(1:M-1,:),1)];

Theta = P/L;

if size(Theta,2) ~= nchoosek(L+M-1,M-1)
    disp('Wrong number of set elements...')
    return
end
