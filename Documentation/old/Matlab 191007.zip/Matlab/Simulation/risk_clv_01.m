function Risk = risk_clv_01(Y,X,theta)

Risk = 1;
for idx_x = 1:numel(X)
    Risk = Risk - max(theta(:,idx_x));
end