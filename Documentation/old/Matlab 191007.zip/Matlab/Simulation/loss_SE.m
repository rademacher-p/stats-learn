function L = loss_SE(y_est,y)

L = (y_est-y)^2;