function Risk_a = risk_dir_01(Y,X,N,alpha)

if sum(alpha(:) == 1) ~= numel(alpha)
    disp('Error: Closed-form 01 Risk only available for uniform model prior');
    Risk_a = NaN;
    return
end

M_y = size(alpha,1);
M_x = size(alpha,2);

M = M_y*M_x;

temp = 1;
for m = 1:M_y
    for n = 0:(ceil((N+M)/m)-1)
        temp = temp + M_x/(N+M) * (-1)^m * nchoosek(M_y,m) * prod(1 - m*n./(N+(1:M-1)));
    end
end 
Risk_a = temp;