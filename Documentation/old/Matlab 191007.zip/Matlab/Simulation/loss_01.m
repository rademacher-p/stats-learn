function L = loss_01(y_hyp,y)

L = 1 - (y_hyp == y);